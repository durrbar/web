<?php

namespace App\Providers;

use Auth;
use Cart;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\Category;
use App\Models\Product;

class ViewComposerServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        View::composer('base::partials.topbar-user-cart', function ($view) {
            $userId = Auth::id();
            $view->with('cartCount', Cart::session($userId)->getContent()->count());
        });
        
        View::composer('tasfiashopping.www.home.cart', function ($view) {
            $userId = Auth::id();
            $view->with('cartCount', Cart::session($userId)->getContent()->count());
        });
        
        View::composer('layouts.partials.tasfiashopping.www.aside.cat-nav', function ($view) {
            $view->with('categories', Category::orderByRaw('-name ASC')->get()->nest());
        });
        
        View::composer('base::partials.navbar.tasfiashopping.www', function ($view) {
            $view->with('categories', Category::orderByRaw('-name ASC')->get()->nest());
        });
        
        View::composer('layouts.partials.tasfiashopping.www.home.index.new-products', function ($view) {
            $view->with('products', Product::orderBy('id','DESC')->limit(8)->get());
        });
        
        View::composer('tasfiashopping.www.home.shop', function ($view) {
            $view->with('products', Product::orderBy('id','DESC')->latest()->paginate(12));
        });
    }
}
