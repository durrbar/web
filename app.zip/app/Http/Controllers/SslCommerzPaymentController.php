<?php

namespace App\Http\Controllers;

use Cart;
use DB;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Order;
use App\Models\Product;
use App\Models\OrderItem;
use App\Models\Location\LocationDivision;
use App\Models\Location\LocationDistrict;
use App\Models\Location\LocationSubDistrict;
use App\Models\Location\LocationBranch;
use App\Models\Location\LocationZip;
use App\Library\SslCommerz\SslCommerzNotification;

class SslCommerzPaymentController extends Controller
{

    public function easyCheckout()
    {
        $userId = Auth::id();
        $divisions = LocationDivision::select('division_id', 'division_name')->orderBy('division_name')->get();
        $districts = LocationDistrict::select('district_id', 'district_name')->orderBy('division_id')->get();
        $sub_districts = LocationSubDistrict::select('sub_district_id', 'sub_district_name')->orderBy('district_id')->get();
        $branches = LocationBranch::select('branch_id', 'branch_name')->orderBy('sub_district_id')->get();
        $zips = LocationZip::select('zip_id', 'zip_code')->orderBy('zip_code')->get();
        
        return view('durrbar.accounts.home.checkout', compact('userId','divisions', 'districts', 'sub_districts', 'branches', 'zips'));
    }

    public function payViaAjax(Request $request)
    {

        $requestData = (array)json_decode($request->cart_json);
        # Here you have to receive all the order data to initate the payment.
        # Lets your oder trnsaction informations are saving in a table called "orders"
        # In orders table order uniq identity is "transaction_id","status" field contain status of the transaction, "amount" is the order amount to be paid and "currency" is for storing Site Currency which will be checked with paid currency.
        
        $post_data = array();
        $post_data['total_amount'] = '1000'; # You cant not pay less than 10
        $post_data['currency'] = "BDT";
        $post_data['tran_id'] = uniqid(); // tran_id must be unique
        
        # CUSTOMER INFORMATION
        $post_data['cus_name'] = $requestData['customer_first_name']." ". $requestData['customer_last_name'];
        $post_data['cus_email'] = $requestData['cus_email'];
        $post_data['cus_add1'] = $requestData['cus_addr1'];
        $post_data['cus_add2'] = "";
        $post_data['cus_city'] = $requestData['cus_district'];
        $post_data['cus_state'] = $requestData['cus_division'];
        $post_data['cus_postcode'] = $requestData['cus_zip'];
        $post_data['cus_country'] = "Bangladesh";
        $post_data['cus_phone'] = $requestData['cus_phone'];
        $post_data['cus_fax'] = "";
        
        # SHIPMENT INFORMATION
        $post_data['ship_name'] = "Store Test";
        $post_data['ship_add1'] = "Dhaka";
        $post_data['ship_add2'] = "Dhaka";
        $post_data['ship_city'] = "Dhaka";
        $post_data['ship_state'] = "Dhaka";
        $post_data['ship_postcode'] = "1000";
        $post_data['ship_phone'] = "";
        $post_data['ship_country'] = "Bangladesh";
        
        $post_data['shipping_method'] = "NO";
        $post_data['product_name'] = "Computer";
        $post_data['product_category'] = "Goods";
        $post_data['product_profile'] = "physical-goods";
        
        # EMI STATUS
        $post_data['emi_option'] = "1";
        $post_data['emi_max_inst_option'] = "12";
        
        #Before  going to initiate the payment order status need to update as Pending.
        $order = Order::updateOrCreate(['transaction_id' => $post_data['tran_id']],[
                'order_number' => 'ORD-'.strtoupper(uniqid()),
                'name' => $post_data['cus_name'],
                'cus_id' => $requestData['customer_id'],
                'branch_id' => $requestData['cus_branch'],
                'email' => $post_data['cus_email'],
                'phone' => $post_data['cus_phone'],
                'amount' => $post_data['total_amount'],
                'item_count' =>  Cart::getTotalQuantity(),
                'status' => 'Pending',
                'address' => $requestData['cus_addr1'],
                'cus_sub_district' => $requestData['cus_sub_district'],
                'cus_district' => $requestData['cus_district'],
                'cus_division' => $requestData['cus_division'],
                'transaction_id' => $post_data['tran_id'],
                'currency' => $post_data['currency']
            ]);
            
        if ($order) {

            $items = Cart::getContent();

            foreach ($items as $item)
            {
                // A better way will be to bring the product id with the cart items
                // you can explore the package documentation to send product id with the cart
                $product = Product::where('name', $item->name)->first();

                $orderItem = new OrderItem([
                    'product_id'    =>  $product->id,
                    'quantity'      =>  $item->quantity,
                    'price'         =>  $item->getPriceSum()
                ]);

                $order->items()->save($orderItem);
            }
        }
        
        $sslc = new SslCommerzNotification();
        # initiate(Transaction Data , false: Redirect to SSLCOMMERZ gateway/ true: Show all the Payement gateway here )
        $payment_options = $sslc->makePayment($post_data, 'checkout', 'json');

        if (!is_array($payment_options)) {
            print_r($payment_options);
            $payment_options = array();
        }

    }

    public function success(Request $request)
    {
        
        $tran_id = $request->input('tran_id');
        $amount = $request->input('amount');
        $currency = $request->input('currency');

        $sslc = new SslCommerzNotification();

        #Check order status in order tabel against the transaction id or order id.
        $order_detials = DB::table('orders')
            ->where('transaction_id', $tran_id)
            ->select('transaction_id', 'status', 'currency', 'amount')->first();

        if ($order_detials->status == 'Pending') {
            $validation = $sslc->orderValidate($tran_id, $amount, $currency, $request->all());

            if ($validation == TRUE) {
                /*
                That means IPN did not work or IPN URL was not set in your merchant panel. Here you need to update order status
                in order table as Processing or Complete.
                Here you can also sent sms or email for successfull transaction to customer
                */
                $update_product = DB::table('orders')
                    ->where('transaction_id', $tran_id)
                    ->update(['status' => 'Processing']);

                $message = "Transaction is successfully Completed";
                return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
            } else {
                /*
                That means IPN did not work or IPN URL was not set in your merchant panel and Transation validation failed.
                Here you need to update order status as Failed in order table.
                */
                $update_product = DB::table('orders')
                    ->where('transaction_id', $tran_id)
                    ->update(['status' => 'Failed']);
                $message = "validation Fail";
                return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
            }
        } else if ($order_detials->status == 'Processing' || $order_detials->status == 'Complete') {
            /*
             That means through IPN Order status already updated. Now you can just show the customer that transaction is completed. No need to udate database.
             */
            $message = "Transaction is successfully Completed";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        } else {
            #That means something wrong happened. You can redirect customer to your product page.
            $message = "Invalid Transaction";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        }


    }

    public function fail(Request $request)
    {
        $tran_id = $request->input('tran_id');

        $order_detials = DB::table('orders')
            ->where('transaction_id', $tran_id)
            ->select('transaction_id', 'status', 'currency', 'amount')->first();

        if ($order_detials->status == 'Pending') {
            $update_product = DB::table('orders')
                ->where('transaction_id', $tran_id)
                ->update(['status' => 'Failed']);
            $message = "Transaction is Falied";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        } else if ($order_detials->status == 'Processing' || $order_detials->status == 'Complete') {
            $message = "Transaction is already Successful";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        } else {
            $message = "Transaction is Invalid";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        }

    }

    public function cancel(Request $request)
    {
        $tran_id = $request->input('tran_id');

        $order_detials = DB::table('orders')
            ->where('transaction_id', $tran_id)
            ->select('transaction_id', 'status', 'currency', 'amount')->first();

        if ($order_detials->status == 'Pending') {
            $update_product = DB::table('orders')
                ->where('transaction_id', $tran_id)
                ->update(['status' => 'Canceled']);
            $message = "Transaction is Cancel";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        } else if ($order_detials->status == 'Processing' || $order_detials->status == 'Complete') {
            $message = "Transaction is already Successful";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        } else {
            $message = "Transaction is Invalid";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        }


    }

    public function ipn(Request $request)
    {
        #Received all the payement information from the gateway
        if ($request->input('tran_id')) #Check transation id is posted or not.
        {

            $tran_id = $request->input('tran_id');

            #Check order status in order tabel against the transaction id or order id.
            $order_details = DB::table('orders')
                ->where('transaction_id', $tran_id)
                ->select('transaction_id', 'status', 'currency', 'amount')->first();

            if ($order_details->status == 'Pending') {
                $sslc = new SslCommerzNotification();
                $validation = $sslc->orderValidate($tran_id, $order_details->amount, $order_details->currency, $request->all());
                if ($validation == TRUE) {
                    /*
                    That means IPN worked. Here you need to update order status
                    in order table as Processing or Complete.
                    Here you can also sent sms or email for successful transaction to customer
                    */
                    $update_product = DB::table('orders')
                        ->where('transaction_id', $tran_id)
                        ->update(['status' => 'Processing']);

                    $message = "Transaction is successfully Completed";
                    return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
                } else {
                    /*
                    That means IPN worked, but Transation validation failed.
                    Here you need to update order status as Failed in order table.
                    */
                    $update_product = DB::table('orders')
                        ->where('transaction_id', $tran_id)
                        ->update(['status' => 'Failed']);

                    $message = "validation Fail";
                    return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
                }

            } else if ($order_details->status == 'Processing' || $order_details->status == 'Complete') {

                #That means Order status already updated. No need to udate database.

                $message = "Transaction is already successfully Completed";
                return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
            } else {
                #That means something wrong happened. You can redirect customer to your product page.

                $message = "Invalid Transaction";
                return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
            }
        } else {
            $message = "Invalid Data";
            return response()->view('layouts.blank', compact('message'), 200)->header("Refresh", "10;url=https://accounts.durrbar.com/settings/billing"); 
        }
    }

}

