<?php

namespace App\Http\Controllers\Location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator,Redirect,Response;
use App\Models\Location\Division;
use App\Models\Location\District;
use App\Models\Location\SubDistrict;
use App\Models\Location\Branch;
use App\Models\Location\Zip;

class LocationController extends Controller
{
    public function boot()
    {
        //
    }
    public function index()
    {
        $divisions = Division::with(['districts', 'sub_districts', 'branches', 'zips'])->latest()->get();
        //return $divisions;
        return view('durrbar.accounts.home.settings', compact('divisions'));
    }
/*    public function getDistrict(Request $request)
    {
        $data['districts'] = District::where("division_id", $request->division_id)->get(["name","id"]);
        return response()->json($data);
    }
    public function getSubdistrict(Request $request)
    {
        $data['sub_districts'] = Subdistrict::where("district_id", $request->district_id)->get(["name","id"]);
        return response()->json($data);
    }
    public function getBranch(Request $request)
    {
        $data['branches'] = Subdistricts::where("sub_district_id", $request->sub_district_id)->get(["name","id"]);
        return response()->json($data);
    }
    public function getZip(Request $request)
    {
        $data['zips'] = Zip::where("branch_id", $request->branch_id)->get(["name","id"]);
        return response()->json($data);
    }
*/
    public function getDistrict($division_id)
    {
        $districts = District::where('division_id','=', $division_id)->orderBy('district_name','ASC')->get();
        return json_encode($districts);
    }
    public function getSubdistrict($district_id)
    {
        $sub_districts = SubDistrict::where('district_id','=', $district_id)->orderBy('sub_district_name','ASC')->get();
        return json_encode($sub_districts);
    }
    public function getBranch($sub_district_id)
    {
        $branches = Branch::where('sub_district_id','=', $sub_district_id)->orderBy('branch_name','ASC')->get();
        return json_encode($branches);
    }
    public function getZip($branch_id)
    {
        $zips = Zip::where('branch_id','=', $branch_id)->orderBy('zip_code','ASC')->get();
        return json_encode($zips);
    }
}
