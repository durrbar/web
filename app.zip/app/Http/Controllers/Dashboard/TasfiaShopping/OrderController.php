<?php

namespace App\Http\Controllers\Dashboard\TasfiaShopping;

use App\Contracts\OrderContract;
use App\Http\Controllers\Dashboard\TasfiaShopping\BaseController;

class OrderController extends BaseController
{
    protected $orderRepository;

    public function __construct(OrderContract $orderRepository)
    {
        $this->orderRepository = $orderRepository;
    }

    public function index()
    {
        $orders = $this->orderRepository->listOrders();
        $this->setPageTitle('Orders', 'List of all orders');
        return view('durrbar.dashboard.tasfiashopping.orders.index', compact('orders'));
    }

    public function show($orderNumber)
    {
        $order = $this->orderRepository->findOrderByNumber($orderNumber);

        $this->setPageTitle('Order Details', $orderNumber);
        return view('durrbar.dashboard.tasfiashopping.orders.show', compact('order'));
    }
}