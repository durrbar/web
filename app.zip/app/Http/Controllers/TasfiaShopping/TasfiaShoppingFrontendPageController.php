<?php

namespace App\Http\Controllers\TasfiaShopping;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TasfiaShopping\TasfiashoppingBrand;
use App\Models\TasfiaShopping\TasfiashoppingCategory;
use App\Models\TasfiaShopping\TasfiashoppingProduct;
use App\Models\TasfiaShopping\TasfiashoppingSlider;
use App\Models\TasfiaShopping\TasfiashoppingSubCategory;
use App\Models\TasfiaShopping\TasfiashoppingSubSubCategory;

class TasfiaShoppingFrontendPageController extends Controller
{
    public function home()
    {
        
        $sliders = TasfiashoppingSlider::where('slider_name', '=', 'Main-Slider')->where('slider_status', '=', 1)->limit(3)->get();

        //return response()->json($categories);
        return view('tasfiashopping.www.home.index', compact('sliders'));
    }
    
    public function category()
    {
        return view('tasfiashopping.www.home.category-page');
    }

    public function productDeatil($id, $slug)
    {
        $categories = TasfiashoppingCategory::with(['subcategory'])->orderBy('category_name_en', 'ASC')->get();
        $product = TasfiashoppingProduct::with(['images'])->findOrFail($id);
        $colors_en = explode(',', $product->product_color_en);
        $colors_bn = explode(',', $product->product_color_bn);
        $size_en = explode(',', $product->product_size_en);
        $size_bn = explode(',', $product->product_size_bn);
        $related_products = TasfiashoppingProduct::where('category_id',$product->category_id)
        ->where('id', '!=', $id)->orderBy('id','DESC')->get();
        //return response()->json($product);
        return view('tasfiashopping.www.home.product', compact(
            'categories',
            'product',
            'colors_en',
            'colors_bn',
            'size_en',
            'size_bn',
            'related_products'
        ));
    }

    public function tagwiseProduct($tag)
    {
        $tag_products = TasfiashoppingProduct::where('status',1)->where('product_tags_en', $tag)
        ->where('product_tags_bn',$tag)->orderBy('id', 'DESC')->paginate(12);
        $categories = TasfiashoppingCategory::with(['subcategory'])->orderBy('category_name_en', 'ASC')->get();
        return view('tasfiashopping.www.home.tags.tags_view', compact('tag_products', 'categories'));
    }

    public function subcategoryProducts($id, $slug)
    {
        $subcategory_products = TasfiashoppingProduct::where('status', 1)->where('subcategory_id', $id)->orderBy('id','DESC')->paginate(12);
        //$categories = Category::with(['subcategory'])->orderBy('category_name_en', 'ASC')->get();
        return view('tasfiashopping.www.home.subcategory.subcategory_product_page', compact('subcategory_products'));
    }

    public function subsubcategoryProducts($id, $slug)
    {
        $subsubcategory_products = TasfiashoppingProduct::where('status', 1)->where('sub_subcategory_id', $id)->orderBy('id','DESC')->paginate(12);
        //$categories = Category::with(['subcategory'])->orderBy('category_name_en', 'ASC')->get();
        return view('tasfiashopping.www.home.subcategory.subsubcategory_product_page', compact('subsubcategory_products'));
    }

    public function productviewAjax($id)
    {
        $product = TasfiashoppingProduct::with(['brand','category'])->findOrFail($id);
        $colors_en = explode(',', $product->product_color_en);
        $size_en = explode(',', $product->product_size_en);
        return response()->json([
            'product' => $product,
            'colors_en' => $colors_en,
            'size_en' => $size_en,
        ],200);
    }
}
