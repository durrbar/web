<?php

namespace App\Http\Controllers\TasfiaShopping;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTasfiashoppingCategoryRequest;
use App\Http\Requests\UpdateTasfiashoppingCategoryRequest;
use App\Models\TasfiaShopping\TasfiashoppingCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Image;

class TasfiaShoppingCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tasfiashoppingCategory = TasfiashoppingCategory::latest()->get();
        return view('durrbar.dashboard.tasfiashopping.categories.index', compact('tasfiashoppingCategory'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('durrbar.dashboard.tasfiashopping.categories.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTasfiashoppingCategoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTasfiashoppingCategoryRequest $request)
    {
            if($request->file('category_image')){
            $upload_location = 'uploads/tasfiashopping/categories/';
            $file = $request->file('category_image');
            $name_gen = hexdec(uniqid()).'.'.$file->getClientOriginalExtension();
            Image::make($file)->resize(600,600)->save(public_path().'/'.$upload_location.$name_gen);
            $save_url = $upload_location.$name_gen;

            TasfiashoppingCategory::create([
                'category_name_en' => $request->input('category_name_en'),
                'category_name_bn' => $request->input('category_name_bn'),
                'category_slug_en' => Str::slug($request->input('category_slug_en')),
                'category_slug_bn' => Str::slug($request->input('category_slug_bn')),
                'category_icon' => $request->input('category_icon'),
                'category_image' => $save_url,
                'meta_description' => $request->input('meta_description'),
                'meta_keywords' => $request->input('meta_keywords'),
                'meta_title' => $request->input('meta_title'),
                'category_description' => $request->input('category_description')
            ]);
        }else{
            TasfiashoppingCategory::create([
                'category_name_en' => $request->input('category_name_en'),
                'category_name_bn' => $request->input('category_name_bn'),
                'category_slug_en' => Str::slug($request->input('category_slug_en')),
                'category_slug_bn' => Str::slug($request->input('category_slug_bn')),
                'category_icon' => $request->input('category_icon'),
                'meta_description' => $request->input('meta_description'),
                'meta_keywords' => $request->input('meta_keywords'),
                'meta_title' => $request->input('meta_title'),
                'category_description' => $request->input('category_description')
            ]);
        }

        $notification = [
            'message' => 'Category Created Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('tasfiashopping.categories.index')->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingCategory  $tasfiashoppingCategory
     * @return \Illuminate\Http\Response
     */
    public function show(TasfiashoppingCategory $tasfiashoppingCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingCategory  $tasfiashoppingCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(TasfiashoppingCategory $category)
    {
        return view('durrbar.dashboard.tasfiashopping.categories.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTasfiashoppingCategoryRequest  $request
     * @param  \App\Models\TasfiaShopping\TasfiashoppingCategory  $tasfiashoppingCategory
     * @return \Illuminate\Http\Response
     */
    public function update(StoreTasfiashoppingCategoryRequest $request, TasfiashoppingCategory $category)
    {
        if($request->file('category_image')){
            if($category->category_image !='default.jpg'){
                unlink($category->category_image);
            }
            $upload_location = 'uploads/tasfiashopping/categories/';
            $file = $request->file('category_image');
            $name_gen = hexdec(uniqid()).'.'.$file->getClientOriginalExtension();
            Image::make($file)->resize(600,600)->save(public_path().'/'.$upload_location.$name_gen);
            $save_url = $upload_location.$name_gen;

            $category->update([
                'category_name_en' => $request->input('category_name_en'),
                'category_name_bn' => $request->input('category_name_bn'),
                'category_slug_en' => Str::slug($request->input('category_slug_en')),
                'category_slug_bn' => Str::slug($request->input('category_slug_bn')),
                'category_icon' => $request->input('category_icon'),
                'category_image' => $save_url,
                'meta_description' => $request->input('meta_description'),
                'meta_keywords' => $request->input('meta_keywords'),
                'meta_title' => $request->input('meta_title'),
                'category_description' => $request->input('category_description')
            ]);
        }else{
            $category->update([
                'category_name_en' => $request->input('category_name_en'),
                'category_name_bn' => $request->input('category_name_bn'),
                'category_slug_en' => Str::slug($request->input('category_slug_en')),
                'category_slug_bn' => Str::slug($request->input('category_slug_bn')),
                'category_icon' => $request->input('category_icon'),
                'meta_description' => $request->input('meta_description'),
                'meta_keywords' => $request->input('meta_keywords'),
                'meta_title' => $request->input('meta_title'),
                'category_description' => $request->input('category_description')
            ]);
        }

        $notification = [
            'message' => 'Category Updated Successfully!!!',
            'alert-type' => 'info'
        ];

        return redirect()->route('tasfiashopping.categories.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingCategory  $tasfiashoppingCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(TasfiashoppingCategory $tasfiashoppingCategory)
    {
        if($tasfiashoppingCategory->category_image !='default.jpg'){
            unlink($tasfiashoppingCategory->category_image);
        }
        $tasfiashoppingCategory->delete();

        $notification = [
            'message' => '$tasfiashoppingCategory Deleted Successfully!!!',
            'alert-type' => 'warning'
        ];

        return redirect()->route('tasfiashopping.categories.index')->with($notification);
    }
}
