<?php

namespace App\Http\Controllers\TasfiaShopping;

use Auth;
use Cart;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CartController extends Controller
{
    public function getCart()
    {
        $userId = Auth::id();
        return view('tasfiashopping.www.home.cart', compact('userId'));
    }

    public function removeItem($id)
    {
        $userId = Auth::id();
        Cart::session($userId)->remove($id);

        if (Cart::session($userId)->isEmpty()) {
            return redirect('/shop')->with('info', 'Cart is empty.');
        }
        return redirect()->back()->with('message', 'Item removed from cart successfully.');
    }

    public function clearCart()
    {
        $userId = Auth::id();
        Cart::session($userId)->clear();

        return redirect('/shop')->with('message', 'All Items removed from cart successfully.');
    }
}