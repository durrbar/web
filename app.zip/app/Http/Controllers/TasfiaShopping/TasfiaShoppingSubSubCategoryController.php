<?php

namespace App\Http\Controllers\TasfiaShopping;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTasfiashoppingSubSubCategoryRequest;
use App\Http\Requests\UpdateTasfiashoppingSubSubCategoryRequest;
use App\Models\TasfiaShopping\TasfiashoppingCategory;
use App\Models\TasfiaShopping\TasfiashoppingSubCategory;
use App\Models\TasfiaShopping\TasfiashoppingSubSubCategory;

class TasfiaShoppingSubSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tasfiashoppingSubSubCategories = TasfiashoppingSubSubCategory::with(['category','subcategory'])->latest()->get();
        return view('durrbar.dashboard.tasfiashopping.subsubcategories.index', compact('tasfiashoppingSubSubCategories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tasfiashoppingCategories = TasfiashoppingCategory::with('subcategory')->latest()->get();
        //dd($categories);
        return view('durrbar.dashboard.tasfiashopping.subsubcategories.add', compact('tasfiashoppingCategories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTasfiashoppingSubSubCategoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTasfiashoppingSubSubCategoryRequest $request)
    {
        // dd($request->all());
        SubSubCategory::create([
            'category_id' => $request->category_id,
            'subcategory_id' => $request->subcategory_id,
            'subsubcategory_name_en' => $request->input('subsubcategory_name_en'),
            'subsubcategory_name_bn' => $request->input('subsubcategory_name_bn'),
            'subsubcategory_slug_en' => Str::slug($request->input('subsubcategory_name_en')),
            'subsubcategory_slug_bn' => Str::slug($request->input('subsubcategory_name_bn')),
        ]);

        $notification = [
            'message' => 'Sub Sub Category Created Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('tasfiashopping.subsubcategories.index')->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubSubCategory  $tasfiashoppingSubSubCategory
     * @return \Illuminate\Http\Response
     */
    public function show(TasfiashoppingSubSubCategory $tasfiashoppingSubSubCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubSubCategory  $tasfiashoppingSubSubCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(TasfiashoppingSubSubCategory $subsubcategory)
    {
        $subsubcategory = TasfiashoppingSubSubCategory::findOrFail($subsubcategory);
        $categories = TasfiashoppingCategory::latest()->get();
        $subcategories = TasfiashoppingSubCategory::latest()->get();
        return view('durrbar.dashboard.tasfiashopping.subsubcategories.edit', compact('categories','subcategories','subsubcategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTasfiashoppingSubSubCategoryRequest  $request
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubSubCategory  $tasfiashoppingSubSubCategory
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTasfiashoppingSubSubCategoryRequest $request, TasfiashoppingSubSubCategory $subsubcategory)
    {
        $subsubcategory = TasfiashoppingSubSubCategory::findOrFail($subsubcategory);
        $subsubcategory->update([
            'category_id' => $request->category_id,
            'subcategory_id' => $request->subcategory_id,
            'subsubcategory_name_en' => $request->input('subsubcategory_name_en'),
            'subsubcategory_name_bn' => $request->input('subsubcategory_name_bn'),
            'subsubcategory_slug_en' => Str::slug($request->input('subsubcategory_name_en')),
            'subsubcategory_slug_bn' => Str::slug($request->input('subsubcategory_name_bn')),
        ]);

        $notification = [
            'message' => 'Sub Sub Category Updated Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('tasfiashopping.subsubcategories.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubSubCategory  $tasfiashoppingSubSubCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(TasfiashoppingSubSubCategory $tasfiashoppingSubSubCategory)
    {
        $subsubCategory = TasfiashoppingSubSubCategory::findOrFail($tasfiashoppingSubSubCategory);
        $subsubCategory->delete();

        $notification = [
            'message' => 'Sub Sub Category Deleted Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('tasfiashopping.subsubcategories.index')->with($notification);
    }
    
    public function getTasfiashoppingSubCategory($category_id)
    {
        $subCategory = TasfiashoppingSubCategory::where('category_id','=', $category_id)->orderBy('subcategory_name_en','ASC')->get();
        return json_encode($subCategory);
    }

    public function getTasfiashoppingSubSubCategory($subcategory_id)
    {
        $subsubCategory = TasfiashoppingSubSubCategory::where('subcategory_id', '=', $subcategory_id)->orderBy('subsubcategory_name_en', 'ASC')->get();
        return json_encode($subsubCategory);
    }
}
