<?php

namespace App\Http\Controllers\TasfiaShopping;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTasfiashoppingSubCategoryRequest;
use App\Http\Requests\UpdateTasfiashoppingSubCategoryRequest;
use App\Models\TasfiaShopping\TasfiashoppingCategory;
use App\Models\TasfiaShopping\TasfiashoppingSubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class TasfiaShoppingSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tasfiashoppingSubCategories = TasfiaShoppingSubCategory::with(['tasfiashoppingCategory'])->latest()->get();
        //return response()->json($subCategories);
        return view('durrbar.dashboard.tasfiashopping.subcategories.index', compact('tasfiashoppingSubCategories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tasfiashoppingCategories = tasfiashoppingCategory::latest()->get();
        return view('durrbar.dashboard.tasfiashopping.subcategories.add', compact('tasfiashoppingCategories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTasfiashoppingSubCategoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTasfiashoppingSubCategoryRequest $request)
    {
        TasfiashoppingSubCategory::create([
            'category_id' => $request->input('category_id'),
            'subcategory_name_en' => $request->input('subcategory_name_en'),
            'subcategory_name_bn' => $request->input('subcategory_name_bn'),
            'subcategory_slug_en' => Str::slug($request->input('subcategory_name_en')),
            'subcategory_slug_bn' => Str::slug($request->input('subcategory_name_bn')),
        ]);

        $notification = [
            'message' => 'Sub Category Created Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('subcategories.index')->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubCategory  $tasfiashoppingSubCategory
     * @return \Illuminate\Http\Response
     */
    public function show(TasfiashoppingSubCategory $tasfiashoppingSubCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubCategory  $tasfiashoppingSubCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(TasfiashoppingSubCategory $subcategory)
    {
        $tasfiashoppingCategories = TasfiashoppingCategory::latest()->get();
        return view('durrbar.dashboard.tasfiashopping.subcategories.edit', compact('tasfiashoppingCategories', 'subcategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTasfiashoppingSubCategoryRequest  $request
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubCategory  $tasfiashoppingSubCategory
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTasfiashoppingSubCategoryRequest $request, TasfiashoppingSubCategory $subcategory)
    {
        //dd($request->all(), $id);
        $subcategory = TasfiashoppingSubCategory::findOrFail($subcategory);
        $subcategory->update([
            'category_id' => $request->category_id,
            'subcategory_name_en' => $request->input('subcategory_name_en'),
            'subcategory_name_bn' => $request->input('subcategory_name_bn'),
            'subcategory_slug_en' => Str::slug($request->input('subcategory_name_en')),
            'subcategory_slug_bn' => Str::slug($request->input('subcategory_name_bn')),
        ]);

        $notification = [
            'message' => 'Sub Category Updated Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('subcategories.index')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TasfiaShopping\TasfiashoppingSubCategory  $tasfiashoppingSubCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(TasfiashoppingSubCategory $tasfiashoppingSubCategory)
    {
        $tasfiashoppingSubCategory = TasfiashoppingSubCategory::findOrFail($id);
        $tasfiashoppingSubCategory->delete();

        $notification = [
            'message' => 'Sub Category Deleted Successfully!!!',
            'alert-type' => 'success'
        ];

        return redirect()->route('subcategories.index')->with($notification);
    }
}
