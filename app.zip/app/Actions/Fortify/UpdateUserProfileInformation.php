<?php

namespace App\Actions\Fortify;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;

class UpdateUserProfileInformation implements UpdatesUserProfileInformation
{
    /**
     * Validate and update the given user's profile information.
     *
     * @param  mixed  $user
     * @param  array  $input
     * @return void
     */
    public function update($user, array $input)
    {
        Validator::make($input, [
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:15'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users')->ignore($user->id),],
            'nid' => ['required', 'string', 'max:19'],
            'address' => ['required', 'string'],
            'division' => 'required',
            'district' => 'required',
            'sub_district' => 'required',
            'branch' => 'required',
            'zip' => 'required',
        ])->validateWithBag('updateProfileInformation');

        if ($input['email'] !== $user->email &&
            $user instanceof MustVerifyEmail) {
            $this->updateVerifiedUser($user, $input);
        } else {
            $user->forceFill([
                'first_name' => $input['first_name'],
                'last_name' => $input['last_name'],
                'email' => $input['email'],
                'phone' => $input['phone'],
                'nid' => $input['nid'],
                'address' => $input['address'],
                'division' => $input['division'],
                'district' => $input['district'],
                'sub_district' => $input['sub_district'],
                'branch' => $input['branch'],
                'zip' => $input['zip'],
            ])->save();
        }
    }

    /**
     * Update the given verified user's profile information.
     *
     * @param  mixed  $user
     * @param  array  $input
     * @return void
     */
    protected function updateVerifiedUser($user, array $input)
    {
        $user->forceFill([
            'first_name' => $input['first_name'],
            'last_name' => $input['last_name'],
            'email' => $input['email'],
            'email_verified_at' => null,
            'phone' => $input['phone'],
            'nid' => $input['nid'],
            'address' => $input['address'],
            'division' => $input['division'],
            'district' => $input['district'],
            'sub_district' => $input['sub_district'],
            'branch' => $input['branch'],
            'zip' => $input['zip'],
        ])->save();

        $user->sendEmailVerificationNotification();
    }
}
