<?php

namespace App\Models\Location;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocationDivision extends Model
{
    use HasFactory;
    
    protected $fillable = ['division_name'];
}
