<?php

namespace App\Models\location;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocationSubDistrict extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'division_id',
        'district_id',
        'sub_district_name',
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }
}
