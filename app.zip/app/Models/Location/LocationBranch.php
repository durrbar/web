<?php

namespace App\Models\location;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocationBranch extends Model
{
    use HasFactory;
    
    public function user() {
        return $this->belongsTo(User::class);
    }
}
