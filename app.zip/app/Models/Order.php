<?php

namespace App\Models;
use Modules\User\Entities\User;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'orders';
    
    protected $fillable = [ 'order_number', 'cus_id', 'branch_id', 'name', 'email', 'phone', 'amount', 'item_count',
    'address', 'cus_sub_district', 'cus_district', 'cus_division', 'status', 'order_status', 'transaction_id', 'currency' ];
    
    public function user()
    {
        return $this->belongsTo(User::class, 'cus_id');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }
}
