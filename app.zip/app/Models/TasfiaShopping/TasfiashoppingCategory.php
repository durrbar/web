<?php

namespace App\Models\TasfiaShopping;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TasfiashoppingCategory extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'category_name_en',
        'category_name_bn',
        'category_slug_en',
        'category_slug_bn',
        'category_icon',
        'category_image'
    ];

    public function subcategory()
    {
        return $this->hasMany(TasfiashoppingSubCategory::class, 'category_id', 'id');
    }

    public function subsubcategory()
    {
        return $this->hasMany(TasfiashoppingSubSubCategory::class, 'category_id', 'id');
    }

    public function products(){
        return $this->hasMany(TasfiashoppingProduct::class,'category_id','id');
    }
}
