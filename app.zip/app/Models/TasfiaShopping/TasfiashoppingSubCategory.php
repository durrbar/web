<?php

namespace App\Models\TasfiaShopping;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TasfiashoppingSubCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        "subcategory_name_en",
        "subcategory_name_bn",
        "subcategory_slug_en",
        "subcategory_slug_bn",
        "category_id"
    ];

    public function tasfiashoppingCategory()
    {
        return $this->belongsTo(TasfiashoppingCategory::class);
    }

    public function tasfiashoppingSubSubCategory()
    {
        return $this->hasMany(TasfiashoppingSubSubCategory::class,'subcategory_id', 'id');
    }
}
