<?php

namespace App\Models\TasfiaShopping;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TasfiashoppingSlider extends Model
{
    use HasFactory;

    protected $fillable = [
        'slider_name',
        'slider_title',
        'slider_description',
        'slider_image',
        'slider_status',
    ];
}