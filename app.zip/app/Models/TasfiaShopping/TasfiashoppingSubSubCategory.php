<?php

namespace App\Models\TasfiaShopping;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\TasfiaShopping\TasfiashoppingCategory;
use App\Models\TasfiaShopping\TasfiashoppingSubCategory;

class TasfiashoppingSubSubCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        "subsubcategory_name_en",
        "subsubcategory_name_bn",
        "subsubcategory_slug_en",
        "subsubcategory_slug_bn",
        "category_id",
        "subcategory_id"
    ];

    public function category()
    {
        return $this->hasOne(TasfiaShoppingCategory::class, 'id', 'category_id');
    }
    public function subcategory()
    {
        return $this->hasOne(TasfiaShoppingSubCategory::class, 'id', 'subcategory_id');
    }
}
