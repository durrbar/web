<?php

namespace App\Models\TasfiaShopping;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TasfiashoppingProduct extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function brand()
    {
        return $this->belongsTo(TasfiashoppingBrand::class, 'brand_id', 'id');
    }

    public function category()
    {
        return $this->belongsTo(TasfiashoppingCategory::class, 'category_id', 'id');
    }

    public function subcategory()
    {
        return $this->belongsTo(TasfiashoppingSubCategory::class, 'subcategory_id', 'id');
    }

    public function subsubcategory()
    {
        return $this->belongsTo(TasfiashoppingSubSubCategory::class, 'sub_subcategory_id', 'id');
    }

    public function images()
    {
        return $this->hasMany(TasfiashoppingImage::class,'product_id', 'id');
    }
}
